﻿for(var i = 0; i < 100; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u77'] = 'center';document.getElementById('u80_img').tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	SetPanelState('u73', 'pd0u73','none','',500,'none','',500);

}
});
gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u6'] = 'top';document.getElementById('u96_img').tabIndex = 0;

u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if (true) {

	SetPanelState('u73', 'pd1u73','none','',500,'none','',500);

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u91'] = 'center';