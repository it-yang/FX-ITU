﻿for(var i = 0; i < 80; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';document.getElementById('u31_img').tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	SetPanelVisibility('u24','hidden','none',500);

}
});
gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'center';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	SetPanelVisibility('u24','','none',500);

}
});
gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u2'] = 'top';document.getElementById('u22_img').tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	SetPanelVisibility('u33','','none',500);

}
});
gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'top';document.getElementById('u57_img').tabIndex = 0;

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	SetPanelVisibility('u76','','none',500);

}
});
gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';